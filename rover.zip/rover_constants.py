# set GPIO Pins
pinTrigger = 7
pinEcho = 19
sensor = 14  # TODO: Change from BCM

# motors
Motor1A = 33
Motor1B = 35
Motor1E = 37

Motor2A = 11
Motor2B = 13
Motor2E = 15

# Counter variables
sample = 10 # how many half revolutions to time
count = 0
start = 0
end = 0
