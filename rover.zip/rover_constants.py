# set GPIO Pins
pinTrigger = 7
pinEcho = 11
sensor = 21  # TODO: Change from BCM

# motors
Motor1A = 16
Motor1B = 18
Motor1E = 22

Motor2A = 19
Motor2B = 21
Motor2E = 23

# Counter variables
sample = 10 # how many half revolutions to time
count = 0
start = 0
end = 0
